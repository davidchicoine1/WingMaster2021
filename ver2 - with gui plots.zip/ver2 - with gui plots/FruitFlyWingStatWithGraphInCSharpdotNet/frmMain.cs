﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitFlyWingStatWithGraphInCSharpdotNet
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            cmbGender.SelectedIndex = 0;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK) //show folder browser dialog
            {
                txtFolderPath.Text = folderBrowserDialog1.SelectedPath; //show selected path on the txtFolderPath text box
                this.LoadFiles(); //call the loadfiles function to load all files in the cmbFiles combo box
            }
        }

        private void LoadFiles()
        {
            cmbFiles.Items.Clear(); //first removing all items from combo box
            if (!string.IsNullOrEmpty(txtFolderPath.Text))
            {                
                string FolderPath = Path.Combine(txtFolderPath.Text, cmbGender.SelectedItem.ToString().ToLower()); //Create Folder Path with user selected folder and the male/female folder
                if (Directory.Exists(FolderPath))
                {
                    string[] CSVFiles = Directory.GetFiles(FolderPath, "*.csv"); //get all CSV files from the folder path
                    //load these csv files to the cmbFiles combo box                    
                    foreach (string file in CSVFiles)
                    {
                        int bsli = file.LastIndexOf(@"\"); //bsli=Back Slash Last Index
                        string filename = file.Substring(bsli + 1, file.Length - (bsli + 1));
                        cmbFiles.Items.Add(filename);
                    }
                    //select first item from combo box
                    if (cmbFiles.Items.Count > 0) //if at there is one item
                    {
                        cmbFiles.SelectedIndex = 0;
                        this.LoadChartData();
                    }
                }                
            }
        }

        private void cmbGender_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.LoadFiles();
        }

        private void cmbFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.LoadChartData();
        }

        private void LoadChartData(bool ShowFolderSelectMessage=true)
        {            
            if (string.IsNullOrEmpty(txtFolderPath.Text))
            {
                if (ShowFolderSelectMessage)
                    MessageBox.Show("Please select folder first.", "Select Folder");
            }
            else
            {
                string FilePath = Path.Combine(txtFolderPath.Text, cmbGender.SelectedItem.ToString().ToLower(), cmbFiles.SelectedItem.ToString());
                float[] x = new float[37];
                float[] y = new float[37];
                ReadValues(FilePath, x, y);

                //Loading Chart

                //Setting Axis
                if (!Global.AUTO_SCALING)
                {                    
                    chart1.ChartAreas[0].AxisX.Minimum = Global.X_AXIS_MINIMUM;
                    chart1.ChartAreas[0].AxisX.Maximum = Global.X_AXIS_MAXIMUM;
                    chart1.ChartAreas[0].AxisX.Interval = Global.X_AXIS_INTERVAL;
                    chart1.ChartAreas[0].AxisY.Minimum = Global.Y_AXIS_MINIMUM;
                    chart1.ChartAreas[0].AxisY.Maximum = Global.Y_AXIS_MAXIMUM;
                    chart1.ChartAreas[0].AxisY.Interval = Global.Y_AXIS_INTERVAL;
                }
                else
                {
                    chart1.ChartAreas[0].AxisX.Minimum = Double.NaN;
                    chart1.ChartAreas[0].AxisX.Maximum = Double.NaN;
                    chart1.ChartAreas[0].AxisX.Interval = Double.NaN;
                    chart1.ChartAreas[0].AxisY.Minimum = Double.NaN;
                    chart1.ChartAreas[0].AxisY.Maximum = Double.NaN;
                    chart1.ChartAreas[0].AxisY.Interval = Double.NaN;
                    chart1.ChartAreas[0].RecalculateAxesScale();
                }

                //Setting Colors
                chart1.Series[0].Color = Global.LINE_COLOR;
                chart1.Series[0].MarkerColor = Global.POINT_COLOR;

                //Setting Widths
                chart1.Series[0].BorderWidth = Global.LINE_WIDTH;
                chart1.Series[0].MarkerSize = Global.POINT_SIZE;

                //Adding Data Points                
                chart1.Series[0].Points.Clear();
                int i;
                for (i = 0; i <= 36; i++)
                {
                    chart1.Series[0].Points.AddXY(x[i], y[i]);                    
                }                
            }
        }

        void ReadValues(string FileNameWithPath, float[] x, float[] y)
        {
            TextFieldParser tfp = new TextFieldParser(FileNameWithPath);
            tfp.Delimiters = new string[] { "," };
            tfp.TextFieldType = FieldType.Delimited;
            tfp.ReadLine(); //skip header
            while (!tfp.EndOfData)
            {
                string[] fields = tfp.ReadFields();
                int i;
                for (i = 0; i <= 36; i++)
                {
                    x[i] = Convert.ToSingle(fields[i * 2]);
                    y[i] = Convert.ToSingle(fields[i * 2 + 1]);
                }
            }
        }

        private void btnOptions_Click(object sender, EventArgs e)
        {
            frmOptions frm = new frmOptions();
            frm.ShowDialog();
            this.LoadChartData(false);
        }

        
    }
}
